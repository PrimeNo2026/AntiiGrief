package de.antigrief;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.entity.BlockDisplay;
import org.bukkit.entity.Display;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Transformation;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Zeigt die Zonenränder als durchsichtige, farbige Glas-Wände an.
 * Die Wände sind Display-Entities (keine Blöcke): man läuft einfach durch, sie blockieren nichts,
 * nehmen keine Klicks an und verändern die Umgebung nicht. Jeder Spieler bekommt nur die Stücke
 * in seiner Nähe (und auf seiner Höhe) zu sehen.
 */
public final class WallRenderer {

    private static final double THICKNESS = 0.12;
    private static final int TILE_HEIGHT = 16;
    private static final int TILE_LAYERS = 3;

    private record Seg(String key, double x, double z, double sx, double sz) {
    }

    private record Want(Zone zone, Seg seg, int bottom, int height) {
    }

    private final JavaPlugin plugin;
    private final ZoneManager zones;
    private final Map<UUID, Map<String, BlockDisplay>> shown = new HashMap<>();

    private boolean enabled = true;
    private double range = 64;
    private int segmentLength = 16;

    public WallRenderer(JavaPlugin plugin, ZoneManager zones) {
        this.plugin = plugin;
        this.zones = zones;
    }

    public void reloadSettings() {
        var c = plugin.getConfig();
        enabled = c.getBoolean("walls.enabled", true);
        range = Math.max(16, Math.min(120, c.getDouble("walls.render-distance", 64)));
        segmentLength = Math.max(4, Math.min(64, c.getInt("walls.segment-length", 16)));
        if (!enabled) {
            clearAll();
        }
    }

    // ----------------------------------------------------------------- Update

    public void update() {
        if (!enabled) {
            return;
        }
        Set<UUID> online = new HashSet<>();
        for (Player p : Bukkit.getOnlinePlayers()) {
            online.add(p.getUniqueId());
            updatePlayer(p);
        }
        Iterator<Map.Entry<UUID, Map<String, BlockDisplay>>> it = shown.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, Map<String, BlockDisplay>> en = it.next();
            if (!online.contains(en.getKey())) {
                removeAll(en.getValue());
                it.remove();
            }
        }
    }

    private void updatePlayer(Player p) {
        Map<String, BlockDisplay> mine = shown.computeIfAbsent(p.getUniqueId(), k -> new HashMap<>());
        Location pl = p.getLocation();
        World world = pl.getWorld();

        Map<String, Want> wanted = new HashMap<>();
        if (!zones.isEmpty()) {
            int minH = world.getMinHeight();
            int maxH = world.getMaxHeight();
            int baseTile = Math.floorDiv(pl.getBlockY(), TILE_HEIGHT) * TILE_HEIGHT - TILE_HEIGHT;
            for (Zone zone : zones.all()) {
                if (!zone.world().equals(world.getName()) || zone.wallDistance(pl) > range) {
                    continue;
                }
                List<Seg> segs = new ArrayList<>();
                collectSegments(zone, pl, segs);
                for (Seg seg : segs) {
                    for (int t = 0; t < TILE_LAYERS; t++) {
                        int y0 = baseTile + t * TILE_HEIGHT;
                        if (y0 + TILE_HEIGHT <= minH || y0 >= maxH) {
                            continue;
                        }
                        int bottom = Math.max(y0, minH);
                        int top = Math.min(y0 + TILE_HEIGHT, maxH);
                        wanted.put(seg.key() + ":" + y0, new Want(zone, seg, bottom, top - bottom));
                    }
                }
            }
        }

        // nicht mehr gebrauchte oder ungültige (z. B. Chunk entladen) Stücke entfernen
        Iterator<Map.Entry<String, BlockDisplay>> it = mine.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, BlockDisplay> en = it.next();
            BlockDisplay d = en.getValue();
            if (!wanted.containsKey(en.getKey()) || !d.isValid()) {
                if (d.isValid()) {
                    d.remove();
                }
                it.remove();
            }
        }

        // fehlende Stücke erzeugen
        for (Map.Entry<String, Want> en : wanted.entrySet()) {
            if (mine.containsKey(en.getKey())) {
                continue;
            }
            Want w = en.getValue();
            int chunkX = ((int) Math.floor(w.seg().x())) >> 4;
            int chunkZ = ((int) Math.floor(w.seg().z())) >> 4;
            if (!world.isChunkLoaded(chunkX, chunkZ)) {
                continue;
            }
            BlockDisplay d = spawn(world, w);
            if (d != null) {
                p.showEntity(plugin, d);
                mine.put(en.getKey(), d);
            }
        }
    }

    private BlockDisplay spawn(World world, Want w) {
        Location loc = new Location(world, w.seg().x(), w.bottom(), w.seg().z());
        Material glass = GlassColors.glassFor(w.zone().rgb());
        Transformation transformation = new Transformation(
                new Vector3f(0f, 0f, 0f), new AxisAngle4f(),
                new Vector3f((float) w.seg().sx(), (float) w.height(), (float) w.seg().sz()),
                new AxisAngle4f());
        try {
            return world.spawn(loc, BlockDisplay.class, d -> {
                d.setBlock(glass.createBlockData());
                d.setTransformation(transformation);
                d.setBrightness(new Display.Brightness(15, 15));
                d.setViewRange(2.5f);
                d.setShadowRadius(0f);
                d.setShadowStrength(0f);
                d.setPersistent(false);
                d.setInvulnerable(true);
                d.setVisibleByDefault(false);
            });
        } catch (Exception e) {
            plugin.getLogger().warning("Wand-Stück konnte nicht erstellt werden: " + e.getMessage());
            return null;
        }
    }

    // --------------------------------------------------------------- Geometrie

    private void collectSegments(Zone zone, Location pl, List<Seg> out) {
        double px = pl.getX();
        double pz = pl.getZ();
        double x1 = zone.minX();
        double x2 = zone.maxX() + 1.0;
        double z1 = zone.minZ();
        double z2 = zone.maxZ() + 1.0;
        String id = String.valueOf(zone.id());
        if (Math.abs(pz - z1) <= range) {
            alongX(id + "n", x1, x2, z1, px, out);
        }
        if (Math.abs(pz - z2) <= range) {
            alongX(id + "s", x1, x2, z2, px, out);
        }
        if (Math.abs(px - x1) <= range) {
            alongZ(id + "w", z1, z2, x1, pz, out);
        }
        if (Math.abs(px - x2) <= range) {
            alongZ(id + "e", z1, z2, x2, pz, out);
        }
    }

    /** Wand entlang der X-Achse (fixes Z). */
    private void alongX(String tag, double x1, double x2, double wallZ, double px, List<Seg> out) {
        double from = Math.max(x1, px - range);
        double to = Math.min(x2, px + range);
        if (from >= to) {
            return;
        }
        int first = (int) Math.floor((from - x1) / segmentLength);
        int last = (int) Math.ceil((to - x1) / segmentLength) - 1;
        for (int i = first; i <= last; i++) {
            double s = x1 + (double) i * segmentLength;
            double e = Math.min(x2, s + segmentLength);
            if (e > s) {
                out.add(new Seg(tag + i, s, wallZ - THICKNESS / 2, e - s, THICKNESS));
            }
        }
    }

    /** Wand entlang der Z-Achse (fixes X). */
    private void alongZ(String tag, double z1, double z2, double wallX, double pz, List<Seg> out) {
        double from = Math.max(z1, pz - range);
        double to = Math.min(z2, pz + range);
        if (from >= to) {
            return;
        }
        int first = (int) Math.floor((from - z1) / segmentLength);
        int last = (int) Math.ceil((to - z1) / segmentLength) - 1;
        for (int i = first; i <= last; i++) {
            double s = z1 + (double) i * segmentLength;
            double e = Math.min(z2, s + segmentLength);
            if (e > s) {
                out.add(new Seg(tag + i, wallX - THICKNESS / 2, s, THICKNESS, e - s));
            }
        }
    }

    // ---------------------------------------------------------------- Aufräumen

    public void removePlayer(UUID id) {
        Map<String, BlockDisplay> mine = shown.remove(id);
        if (mine != null) {
            removeAll(mine);
        }
    }

    public void clearAll() {
        for (Map<String, BlockDisplay> mine : shown.values()) {
            removeAll(mine);
        }
        shown.clear();
    }

    private static void removeAll(Map<String, BlockDisplay> map) {
        for (BlockDisplay d : map.values()) {
            if (d.isValid()) {
                d.remove();
            }
        }
        map.clear();
    }
}
