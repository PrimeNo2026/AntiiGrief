package de.antigrief;

import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Display;
import org.bukkit.entity.Player;
import org.bukkit.entity.TextDisplay;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.util.Transformation;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Zeigt jede Zonenwand als EINE große, durchsichtige, einfarbige Fläche (wie ein gefärbter unsichtbarer Block).
 * <p>
 * Technik: Jede Wand ist ein Text-Display mit farbigem Hintergrund, das auf die richtige Größe gezogen
 * wird. Display-Entities haben keine Kollision, keine Hitbox und keinen Einfluss auf Blöcke.
 * Die Entities sitzen immer in der Nähe des Spielers (Anker) und werden per Transformation an die echte
 * Position der Wand "verschoben". So verschwindet die Wand nicht, wenn sie weit weg ist, und der
 * Entity-Tracking-Bereich des Servers spielt keine Rolle.
 */
public final class WallRenderer {

    /** Anzahl Leerzeichen pro Zeile und Zeilen: je größer, desto genauer die Größenberechnung. */
    private static final int SPACES = 200;
    private static final int LINES = 6;
    private static final int TEXT_WIDTH_PX = SPACES * 4;
    private static final double REANCHOR_DISTANCE = 32;
    private static final double EPS = 0.01;
    private static final int HEIGHT_MARGIN = 16;

    private static final class PlayerWalls {
        World world;
        Location anchor;
        final Map<String, TextDisplay> entities = new HashMap<>();
    }

    private final JavaPlugin plugin;
    private final ZoneManager zones;
    private final Map<UUID, PlayerWalls> shown = new HashMap<>();

    private boolean enabled = true;
    private double opacity = 0.30;
    private double maxDistance = 600;
    private double pixelSize = 0.025;

    public WallRenderer(JavaPlugin plugin, ZoneManager zones) {
        this.plugin = plugin;
        this.zones = zones;
    }

    public void reloadSettings() {
        var c = plugin.getConfig();
        boolean wasEnabled = enabled;
        enabled = c.getBoolean("walls.enabled", true);
        opacity = Math.max(0.03, Math.min(1.0, c.getDouble("walls.opacity", 0.30)));
        maxDistance = Math.max(32, c.getDouble("walls.max-distance", 600));
        pixelSize = c.getDouble("walls.pixel-size", 0.025);
        if (pixelSize <= 0) {
            pixelSize = 0.025;
        }
        // geänderte Einstellungen: alles neu aufbauen
        if (!enabled || wasEnabled) {
            clearAll();
        }
    }

    // ----------------------------------------------------------------- Update

    public void update() {
        if (!enabled) {
            return;
        }
        Set<UUID> online = new HashSet<>();
        for (Player p : Bukkit.getOnlinePlayers()) {
            online.add(p.getUniqueId());
            updatePlayer(p);
        }
        Iterator<Map.Entry<UUID, PlayerWalls>> it = shown.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<UUID, PlayerWalls> en = it.next();
            if (!online.contains(en.getKey())) {
                removeAll(en.getValue());
                it.remove();
            }
        }
    }

    private void updatePlayer(Player p) {
        PlayerWalls pw = shown.computeIfAbsent(p.getUniqueId(), k -> new PlayerWalls());
        Location pl = p.getLocation();
        World world = pl.getWorld();

        if (pw.world != world) {
            removeAll(pw);
            pw.world = world;
            pw.anchor = null;
        }

        // Welche Zonen sind relevant?
        Map<Integer, Zone> wanted = new HashMap<>();
        for (Zone zone : zones.all()) {
            if (zone.world().equals(world.getName()) && zone.wallDistance(pl) <= maxDistance) {
                wanted.put(zone.id(), zone);
            }
        }

        // Anker neu setzen, wenn der Spieler sich weit entfernt hat
        boolean reanchor = pw.anchor == null;
        if (!reanchor) {
            double dx = pl.getX() - pw.anchor.getX();
            double dz = pl.getZ() - pw.anchor.getZ();
            double dy = pl.getY() - pw.anchor.getY();
            reanchor = Math.hypot(dx, dz) > REANCHOR_DISTANCE || Math.abs(dy) > REANCHOR_DISTANCE;
        }
        if (reanchor) {
            pw.anchor = new Location(world, Math.floor(pl.getX()), Math.floor(pl.getY()), Math.floor(pl.getZ()));
        }

        // Entities von nicht mehr relevanten Zonen (oder ungültige) entfernen
        Iterator<Map.Entry<String, TextDisplay>> it = pw.entities.entrySet().iterator();
        while (it.hasNext()) {
            Map.Entry<String, TextDisplay> en = it.next();
            int zoneId = Integer.parseInt(en.getKey().substring(0, en.getKey().indexOf(':')));
            TextDisplay d = en.getValue();
            if (!wanted.containsKey(zoneId) || !d.isValid()) {
                if (d.isValid()) {
                    d.remove();
                }
                it.remove();
            }
        }

        // Fehlende Wände erzeugen, bei neuem Anker alle verschieben
        for (Zone zone : wanted.values()) {
            for (int quad = 0; quad < 8; quad++) {
                String key = zone.id() + ":" + quad;
                TextDisplay d = pw.entities.get(key);
                Transformation tr = transformation(zone, quad, world, pw.anchor);
                if (d == null) {
                    d = spawn(world, pw.anchor, zone, tr);
                    if (d != null) {
                        p.showEntity(plugin, d);
                        pw.entities.put(key, d);
                    }
                } else if (reanchor) {
                    d.teleport(pw.anchor);
                    d.setTransformation(tr);
                }
            }
        }
    }

    private TextDisplay spawn(World world, Location anchor, Zone zone, Transformation tr) {
        String line = " ".repeat(SPACES);
        Component text = Component.text(String.join("\n", Collections.nCopies(LINES, line)));
        int alpha = (int) Math.round(opacity * 255);
        int rgb = zone.rgb();
        Color background = Color.fromARGB(alpha, (rgb >> 16) & 255, (rgb >> 8) & 255, rgb & 255);
        try {
            return world.spawn(anchor, TextDisplay.class, d -> {
                d.text(text);
                d.setLineWidth(100000);
                d.setDefaultBackground(false);
                d.setBackgroundColor(background);
                d.setSeeThrough(false);
                d.setShadowed(false);
                d.setBillboard(Display.Billboard.FIXED);
                d.setBrightness(new Display.Brightness(15, 15));
                d.setViewRange(4f);
                d.setTransformation(tr);
                d.setPersistent(false);
                d.setInvulnerable(true);
                d.setVisibleByDefault(false);
            });
        } catch (Exception e) {
            plugin.getLogger().warning("Wand konnte nicht erstellt werden: " + e.getMessage());
            return null;
        }
    }

    // --------------------------------------------------------------- Geometrie

    /**
     * Berechnet die Transformation für eine der 8 Flächen einer Zone (4 Wände x 2 Seiten).
     * quad: 0/1 = Nordwand (Blick nach +Z / -Z), 2/3 = Südwand, 4/5 = Westwand (Blick +X / -X), 6/7 = Ostwand.
     * Das Text-Display-Rechteck liegt lokal bei x in [a0, a1], y in [0, hq] (in Blöcken bei Skalierung 1).
     */
    Transformation transformation(Zone zone, int quad, World world, Location anchor) {
        double ps = pixelSize;
        double wq = ps * (TEXT_WIDTH_PX + 1);
        double a0 = -ps * TEXT_WIDTH_PX / 2.0;
        double a1 = ps * (TEXT_WIDTH_PX / 2.0 + 1);
        double hq = ps * 10 * LINES;

        double yBottom = world.getMinHeight() - HEIGHT_MARGIN;
        double height = (world.getMaxHeight() + HEIGHT_MARGIN) - yBottom;
        double sy = height / hq;

        double x1 = zone.minX();
        double x2 = zone.maxX() + 1.0;
        double z1 = zone.minZ();
        double z2 = zone.maxZ() + 1.0;
        double ax = anchor.getX();
        double ay = anchor.getY();
        double az = anchor.getZ();
        double ty = yBottom - ay;

        boolean alongX = quad < 4;           // Nord-/Südwand laufen entlang der X-Achse
        double length = alongX ? x2 - x1 : z2 - z1;
        double sx = length / wq;
        boolean positive = quad % 2 == 0;    // Blickrichtung +Z bzw. +X

        double tx;
        double tz;
        float angle;
        if (alongX) {
            double wallZ = quad < 2 ? z1 : z2;
            tz = (wallZ + (positive ? EPS : -EPS)) - az;
            if (positive) {
                angle = 0f;
                tx = x1 - ax - a0 * sx;
            } else {
                angle = (float) Math.PI;
                tx = x1 - ax + a1 * sx;
            }
        } else {
            double wallX = quad < 6 ? x1 : x2;
            tx = (wallX + (positive ? EPS : -EPS)) - ax;
            if (positive) {
                angle = (float) (Math.PI / 2);
                tz = z1 - az + a1 * sx;
            } else {
                angle = (float) (-Math.PI / 2);
                tz = z1 - az - a0 * sx;
            }
        }

        return new Transformation(
                new Vector3f((float) tx, (float) ty, (float) tz),
                new AxisAngle4f(angle, 0f, 1f, 0f),
                new Vector3f((float) sx, (float) sy, 1f),
                new AxisAngle4f());
    }

    // ---------------------------------------------------------------- Aufräumen

    public void removePlayer(UUID id) {
        PlayerWalls pw = shown.remove(id);
        if (pw != null) {
            removeAll(pw);
        }
    }

    public void clearAll() {
        for (PlayerWalls pw : shown.values()) {
            removeAll(pw);
        }
        shown.clear();
    }

    private static void removeAll(PlayerWalls pw) {
        for (TextDisplay d : pw.entities.values()) {
            if (d.isValid()) {
                d.remove();
            }
        }
        pw.entities.clear();
    }

    /** Nur für Tests/Logs. */
    List<String> debugKeys(UUID id) {
        PlayerWalls pw = shown.get(id);
        return pw == null ? List.of() : List.copyOf(pw.entities.keySet());
    }
}
