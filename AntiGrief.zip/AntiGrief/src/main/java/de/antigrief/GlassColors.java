package de.antigrief;

import org.bukkit.Material;

/** Sucht zu einer Zonenfarbe das passende gefärbte Glas. */
public final class GlassColors {

    private static final String[] NAMES = {
            "WHITE", "ORANGE", "MAGENTA", "LIGHT_BLUE", "YELLOW", "LIME", "PINK", "GRAY",
            "LIGHT_GRAY", "CYAN", "PURPLE", "BLUE", "BROWN", "GREEN", "RED", "BLACK"
    };
    private static final int[] RGB = {
            0xFFFFFF, 0xFF8A1F, 0xE040E0, 0x6FB6FF, 0xFFE53B, 0x7CFC4A, 0xFF9ACB, 0x6B6B6B,
            0xB5B5B5, 0x2FD1D1, 0xA64BFF, 0x3B6BFF, 0x8B5A2B, 0x2E9E3A, 0xFF3B3B, 0x1A1A1A
    };

    private GlassColors() {
    }

    public static Material glassFor(int rgb) {
        int r = (rgb >> 16) & 255;
        int g = (rgb >> 8) & 255;
        int b = rgb & 255;
        int best = 0;
        long bestDist = Long.MAX_VALUE;
        for (int i = 0; i < RGB.length; i++) {
            int dr = r - ((RGB[i] >> 16) & 255);
            int dg = g - ((RGB[i] >> 8) & 255);
            int db = b - (RGB[i] & 255);
            long dist = (long) dr * dr + (long) dg * dg + (long) db * db;
            if (dist < bestDist) {
                bestDist = dist;
                best = i;
            }
        }
        Material m = Material.matchMaterial(NAMES[best] + "_STAINED_GLASS");
        return m != null ? m : Material.GLASS;
    }
}
