rootProject.name = "AntiGrief"
